Los archivos de la linked list y del hash tree llevan modificaciones.
Para buscarlas en esta practica las podemos hacer con la clave
P2: 

Por ejemplo:
```c
/*P2: cambiado el tipo de int a char*/
//int key;
char *key
```
