#ifndef _FILE_PARSER_H
#define _FILE_PARSER_H
#include <stdio.h>
#include "hash-list.h"



/* nomes fem visible aquesta funcio */
Hash_list *fparser(FILE *fl);

#endif
